

# TODO: Step 1 - get shape (it can't be blank and must be a valid shape!)
def get_shape():
    prompt = "Shape?: "
    shapeList = ['square', 'triangle', 'pyramid', 'rectangle', 'reverse triangle', 'parallelogram']
    while True:
        shape = input(prompt)
        shape = shape.lower()
        try:
            shape in shapeList[0:]
        except:
            continue
        if shape not in shapeList[0:]:
            continue
        break
    return shape


# TODO: Step 1 - get height (it must be int!)
def get_height():
    prompt = "Height?: "
    while True:
        height = input(prompt)
        try:
            height = int(height)
        except:
            continue
        if height < 0 or height > 81:
            continue
        break
    return height


# TODO: Step 2
def draw_pyramid(height, outline):
    w = height*2 -1
    m = w//2
    i = 1

    if outline == False:
        while (i <= height):
            j = 0
            while (j < m + i):
                if (j <= (m-i)):
                    print(" ", end='')
                else:
                    print("*", end='')
                j += 1
            print ("")
            i+=1
    else:
        i = 0
        while(i != height):
            j = 0
            while(j < m + i + 1):
                if(j == m - i or j == m + i or i == height-1):
                    print("*", end='')
                else:
                    print(" ",end='')
                j+=1
            print ("")
            i+=1



# TODO: Step 3
def draw_square(height, outline):
    i = 0
    if outline == False:
        while i != height:
            j = 0
            while j != height:            
                print("*", end='')
                j += 1
            print("")
            i += 1
    else:
        while (i != height):
            j = 0
            while (j < height):
                if i==0 or i == height - 1 or j==0 or j == height - 1:
                    print("*", end='')
                else:
                    print(" ", end='')
                j += 1
            print("")
            i += 1


# TODO: Step 4
def draw_triangle(height, outline):
    i = 1
    if outline == False:
        while(i <= height):
            j = 0
            while(j!=i):
                print("*", end='')
                j += 1
            print("")
            i += 1
    else:
        while(i <= height):
            j = 0
            while(j!=i):
                if (i==height or j==0 or j==i-1):
                    print("*", end='')
                else:
                    print(" ",end='')
                j += 1
            print("")
            i += 1


def draw_rectangle(height, outline):
    i = 0
    w = height//2 + 1
    if outline == False:
        while i != height:
            j = 0
            while j != w:            
                print("*", end='')
                j += 1
            print("")
            i += 1
    else:
        while (i != height):
            j = 0
            while (j < w):
                if i==0 or i == height - 1 or j==0 or j == w - 1:
                    print("*", end='')
                else:
                    print(" ", end='')
                j += 1
            print("")
            i += 1


def draw_parallelogram(height, outline):
    i = 0
    w = height *2 - 1
    if outline == False:
        while(i != height):
            s = height - i
            j=0
            while(s >= 0):
                print(" ", end='')
                s-=1
            while(j <= w):
                print("*", end='')
                j+= 1
            i+=1
            print("")
    
    else:
        while(i != height):
            s = height - i
            j=0
            while(s >= 0):
                print(" ", end='')
                s-=1
            while(j <= w):
                if j == 0 or j== w or i == 0 or i == height - 1:
                    print("*", end='')
                else:
                    print(" ", end='')
                j+= 1
            i+=1
            print("")



def draw_updtriangle(height, outline):
    i = 0
    if outline == False:
        while(i <= height):
            j = height
            while(j!=i):
                print("*", end='')
                j -= 1
            print("")
            i += 1
    else:
        while(i <= height):
            j = height
            while(j!=i):
                if (i==0 or j==height or j==i+1):
                    print("*", end='')
                else:
                    print(" ",end='')
                j -= 1
            print("")
            i += 1


# TODO: Steps 2 to 4, 6 - add support for other shapes
def draw(shape, height, outline):
    if shape == "pyramid":
        draw_pyramid(height, outline)
    elif shape == 'square':
        draw_square(height, outline)
    elif shape == 'triangle':
        draw_triangle(height, outline)
    elif shape == 'rectangle':
        draw_rectangle(height, outline)
    elif shape == 'reverse triangle':
        draw_updtriangle(height, outline)
    elif shape == 'parallelogram':
        draw_parallelogram(height, outline)
    else:
        print("Error")


# TODO: Step 5 - get input from user to draw outline or solid
def get_outline():
    prompt = "Outline only? (y/N): "
    while True:
        outline = input(prompt)
        outline = outline.lower()
        if outline == 'y':
            return True
        elif outline == 'n' or outline == '':
            return False
        else:
            continue
        break

if __name__ == "__main__":
    shape_param = get_shape()
    height_param = get_height()
    outline_param = get_outline()
    draw(shape_param, height_param, outline_param)

