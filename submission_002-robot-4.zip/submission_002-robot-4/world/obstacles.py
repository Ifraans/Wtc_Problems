import random

my_obstacles = []


def is_position_blocked(x,y):
    """Test if there is an obsticle at position

    Args:
        x (int): test position x
        y (int): test position y

    Returns:
        bool: is there an obsticle at position?
    """    
    for obst_x,obst_y in my_obstacles:
        if obst_x <= x <= obst_x + 4 and obst_y <= y <= obst_y + 4:
            return True

    return False


def is_path_blocked(x1, y1, x2, y2):
    """Test if path is blocked by testing each position bewteen current
    position and destination

    Args:
        x1 (int): current x
        y1 (int): current y
        x2 (int): destination x
        y2 (int): destination y

    Returns:
        bool: is path blocked?
    """    
    if x1 == x2:
        if y2 < y1:
            y1, y2 = y2, y1
        for j in range(y1,y2+1):
            if is_position_blocked(x1,j):
                return True

    if y1 == y2:
        if x2 < x1:
            x1, x2 = x2, x1
        for j in range(x1,x2+1):
            if is_position_blocked(j,y1):
                return True

    return False


def get_obstacles():
    return my_obstacles


def create_obstacles(min_x, max_x, min_y, max_y):
    """Create random amount of obstacles in specified area

    Args:
        min_x (int): min x limit
        max_x (int): max x limit
        min_y (int): min y limit
        max_y (int): max y limit
    """    
    global my_obstacles
    my_obstacles = []
    obstacle_amount = random.randint(1,10)

    for i in range(0,obstacle_amount):
        x = random.randint(min_x, max_x)
        y = random.randint(min_y, max_y)

        if is_position_blocked(x,y):
            i -= 1
        else:
            my_obstacles.append((x,y))



