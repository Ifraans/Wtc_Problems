
import turtle


screen = turtle.Screen()

t = turtle.Turtle()

t.setheading(90)

t.penup()


# variables tracking position and direction
position_x = 0
position_y = 0
directions = ['forward', 'right', 'back', 'left']
current_direction_index = 0

# area limit vars
min_y, max_y = -200, 200
min_x, max_x = -100, 100

import world.obstacles

def create_obstacles():
    """Call world.obstacles.create_obstacles to create obstacles then draw them
    """    
    world.obstacles.create_obstacles(min_x, max_x, min_y, max_y)

    for x,y in world.obstacles.get_obstacles():
        t_two.penup()
        t_two.goto(x,y)
        t_two.begin_fill()
        t_two.pendown()
        t_two.goto(x + 4,y)
        t_two.goto(x + 4,y + 4)
        t_two.goto(x,y + 4)
        t_two.goto(x,y)
        t_two.end_fill()


t_two = turtle.Turtle()
t_two.color('red')
t_two._delay(0)
t_two.width(2)
t_two.hideturtle()
t_two.penup()
t_two.goto(max_x,max_y)
t_two.pendown()
t_two.goto(min_x,max_y)
t_two.goto(min_x,min_y)
t_two.goto(max_x,min_y)
t_two.goto(max_x,max_y)
t_two.penup()


def is_position_allowed(new_x, new_y):
    """
    Checks if the new position will still fall within the max area limit
    :param new_x: the new/proposed x position
    :param new_y: the new/proposed y position
    :return: True if allowed, i.e. it falls in the allowed area, else False
    """
    flag = world.obstacles.is_path_blocked(position_x,position_y,new_x,new_y)

    return (min_x <= new_x <= max_x and min_y <= new_y <= max_y), not flag


def show_position(robot_name):
    """changes the position of the robot

    Args:
        robot_name (string): name of robot
    """    
    t.setheading(-(current_direction_index * 90) + 90)
    t.goto(position_x,position_y)
