import unittest
import io
import sys
import robot
from unittest.mock import patch
from io import StringIO
import world.obstacles as obstacles


class TestToyRobot(unittest.TestCase):

    def test_add_command_history(self):
        """Test is command history gets added correctly
        """      
        robot.history = []  
        commands = ['forward 10','right','back 10']
        
        for item in commands:
            robot.add_to_history(item)
        self.assertEqual(robot.history,['forward 10','right','back 10'])
        robot.history = []


    @patch('sys.stdin', StringIO("Hoot\nForward 10\nright\nback 10\nreplay\noff"))
    def test_replay(self):
        """Test replay funtionality
        """        
        obstacles.random.randint = lambda a, b: 0
        sys.stdout = io.StringIO()
        robot.robot_start()
        self.assertEqual(sys.stdout.getvalue(),'''What do you want to name your robot? Hoot: Hello kiddo!
Hoot: What must I do next?  > Hoot moved forward by 10 steps.
 > Hoot now at position (0,10).
Hoot: What must I do next?  > Hoot turned right.
 > Hoot now at position (0,10).
Hoot: What must I do next?  > Hoot moved back by 10 steps.
 > Hoot now at position (-10,10).
Hoot: What must I do next?  > Hoot moved forward by 10 steps.
 > Hoot now at position (0,10).
 > Hoot turned right.
 > Hoot now at position (0,10).
 > Hoot moved back by 10 steps.
 > Hoot now at position (0,20).
 > Hoot replayed 3 commands.
 > Hoot now at position (0,20).
Hoot: What must I do next? Hoot: Shutting down..\n''')


    @patch('sys.stdin', StringIO("Hoot\nForward 10\nright\nback 10\nreplay silent\noff"))
    def test_replay_silent(self):
        """Test replay silent
        """   
        obstacles.random.randint = lambda a, b: 0     
        sys.stdout = io.StringIO()
        robot.robot_start()
        self.assertEqual(sys.stdout.getvalue(),'''What do you want to name your robot? Hoot: Hello kiddo!
Hoot: What must I do next?  > Hoot moved forward by 10 steps.
 > Hoot now at position (0,10).
Hoot: What must I do next?  > Hoot turned right.
 > Hoot now at position (0,10).
Hoot: What must I do next?  > Hoot moved back by 10 steps.
 > Hoot now at position (-10,10).
Hoot: What must I do next?  > Hoot replayed 3 commands silently.
 > Hoot now at position (0,20).
Hoot: What must I do next? Hoot: Shutting down..\n''')


    @patch('sys.stdin', StringIO("Hoot\nForward 10\nright\nback 10\nreplay reversed\noff"))
    def test_replay_reversed(self):
        """Test replay reversed
        """   
        obstacles.random.randint = lambda a, b: 0     
        sys.stdout = io.StringIO()
        robot.robot_start()
        self.assertEqual(sys.stdout.getvalue(),'''What do you want to name your robot? Hoot: Hello kiddo!
Hoot: What must I do next?  > Hoot moved forward by 10 steps.
 > Hoot now at position (0,10).
Hoot: What must I do next?  > Hoot turned right.
 > Hoot now at position (0,10).
Hoot: What must I do next?  > Hoot moved back by 10 steps.
 > Hoot now at position (-10,10).
Hoot: What must I do next?  > Hoot moved back by 10 steps.
 > Hoot now at position (-20,10).
 > Hoot turned right.
 > Hoot now at position (-20,10).
 > Hoot moved forward by 10 steps.
 > Hoot now at position (-20,0).
 > Hoot replayed 3 commands in reverse.
 > Hoot now at position (-20,0).
Hoot: What must I do next? Hoot: Shutting down..\n''')


    @patch('sys.stdin', StringIO("Hoot\nForward 10\nright\nback 10\nreplay reversed silent\noff"))
    def test_replay_reversed_silent(self):
        """Test replay reversed silent
        """        
        obstacles.random.randint = lambda a, b: 0
        sys.stdout = io.StringIO()
        robot.robot_start()
        self.assertEqual(sys.stdout.getvalue(),'''What do you want to name your robot? Hoot: Hello kiddo!
Hoot: What must I do next?  > Hoot moved forward by 10 steps.
 > Hoot now at position (0,10).
Hoot: What must I do next?  > Hoot turned right.
 > Hoot now at position (0,10).
Hoot: What must I do next?  > Hoot moved back by 10 steps.
 > Hoot now at position (-10,10).
Hoot: What must I do next?  > Hoot replayed 3 commands in reverse silently.
 > Hoot now at position (-20,0).
Hoot: What must I do next? Hoot: Shutting down..\n''')


    @patch('sys.stdin', StringIO("Hobbo\nForward 10\nright\nback 10\nleft\nreplay 2\noff"))
    def test_replay_standard_limit_range(self):
        """Test replay standard range
        """        
        obstacles.random.randint = lambda a, b: 0
        sys.stdout = io.StringIO()
        robot.robot_start()
        self.assertEqual(sys.stdout.getvalue(),'''What do you want to name your robot? Hobbo: Hello kiddo!
Hobbo: What must I do next?  > Hobbo moved forward by 10 steps.
 > Hobbo now at position (0,10).
Hobbo: What must I do next?  > Hobbo turned right.
 > Hobbo now at position (0,10).
Hobbo: What must I do next?  > Hobbo moved back by 10 steps.
 > Hobbo now at position (-10,10).
Hobbo: What must I do next?  > Hobbo turned left.
 > Hobbo now at position (-10,10).
Hobbo: What must I do next?  > Hobbo moved back by 10 steps.
 > Hobbo now at position (-10,0).
 > Hobbo turned left.
 > Hobbo now at position (-10,0).
 > Hobbo replayed 2 commands.
 > Hobbo now at position (-10,0).
Hobbo: What must I do next? Hobbo: Shutting down..\n''')


    @patch('sys.stdin', StringIO("Hobbo\nForward 1\nforward 2\nforward 3\nforward 4\nforward 5\nreplay 2 silent\noff"))
    def test_replay_standard_limit_range_silent(self):
        """Test replay standard range silent
        """   
        obstacles.random.randint = lambda a, b: 0     
        sys.stdout = io.StringIO()
        robot.robot_start()
        self.assertEqual(sys.stdout.getvalue(),'''What do you want to name your robot? Hobbo: Hello kiddo!
Hobbo: What must I do next?  > Hobbo moved forward by 1 steps.
 > Hobbo now at position (0,1).
Hobbo: What must I do next?  > Hobbo moved forward by 2 steps.
 > Hobbo now at position (0,3).
Hobbo: What must I do next?  > Hobbo moved forward by 3 steps.
 > Hobbo now at position (0,6).
Hobbo: What must I do next?  > Hobbo moved forward by 4 steps.
 > Hobbo now at position (0,10).
Hobbo: What must I do next?  > Hobbo moved forward by 5 steps.
 > Hobbo now at position (0,15).
Hobbo: What must I do next?  > Hobbo replayed 2 commands silently.
 > Hobbo now at position (0,24).
Hobbo: What must I do next? Hobbo: Shutting down..\n''')


    @patch('sys.stdin', StringIO("Boot\nForward 10\nright\nback 10\nleft\nreplay 2 reversed\noff"))
    def test_replay_standard_limit_range_reversed(self):
        """Test repaly standard range reversed
        """        
        obstacles.random.randint = lambda a, b: 0
        sys.stdout = io.StringIO()
        robot.robot_start()
        self.assertEqual(sys.stdout.getvalue(),'''What do you want to name your robot? Boot: Hello kiddo!
Boot: What must I do next?  > Boot moved forward by 10 steps.
 > Boot now at position (0,10).
Boot: What must I do next?  > Boot turned right.
 > Boot now at position (0,10).
Boot: What must I do next?  > Boot moved back by 10 steps.
 > Boot now at position (-10,10).
Boot: What must I do next?  > Boot turned left.
 > Boot now at position (-10,10).
Boot: What must I do next?  > Boot turned right.
 > Boot now at position (-10,10).
 > Boot moved forward by 10 steps.
 > Boot now at position (0,10).
 > Boot replayed 2 commands in reverse.
 > Boot now at position (0,10).
Boot: What must I do next? Boot: Shutting down..\n''')


    @patch('sys.stdin', StringIO("Yelloo\nForward 10\nright\nback 10\nleft\nreplay 2 silent reversed\noff"))
    def test_replay_standard_limit_range_silent_reversed(self):
        """test standard range silent reversed
        """        
        obstacles.random.randint = lambda a, b: 0
        sys.stdout = io.StringIO()
        robot.robot_start()
        self.assertEqual(sys.stdout.getvalue(),'''What do you want to name your robot? Yelloo: Hello kiddo!
Yelloo: What must I do next?  > Yelloo moved forward by 10 steps.
 > Yelloo now at position (0,10).
Yelloo: What must I do next?  > Yelloo turned right.
 > Yelloo now at position (0,10).
Yelloo: What must I do next?  > Yelloo moved back by 10 steps.
 > Yelloo now at position (-10,10).
Yelloo: What must I do next?  > Yelloo turned left.
 > Yelloo now at position (-10,10).
Yelloo: What must I do next?  > Yelloo replayed 2 commands in reverse silently.
 > Yelloo now at position (0,10).
Yelloo: What must I do next? Yelloo: Shutting down..\n''')


    @patch('sys.stdin', StringIO("Lop\nForward 10\nright\nback 10\nleft\nforward 5\nleft\nback 5\nreplay 4-2\noff"))
    def test_replay_limit_range(self):
        """Test full limit range
        """        
        obstacles.random.randint = lambda a, b: 0
        sys.stdout = io.StringIO()
        robot.robot_start()
        self.assertEqual(sys.stdout.getvalue(),'''What do you want to name your robot? Lop: Hello kiddo!
Lop: What must I do next?  > Lop moved forward by 10 steps.
 > Lop now at position (0,10).
Lop: What must I do next?  > Lop turned right.
 > Lop now at position (0,10).
Lop: What must I do next?  > Lop moved back by 10 steps.
 > Lop now at position (-10,10).
Lop: What must I do next?  > Lop turned left.
 > Lop now at position (-10,10).
Lop: What must I do next?  > Lop moved forward by 5 steps.
 > Lop now at position (-10,15).
Lop: What must I do next?  > Lop turned left.
 > Lop now at position (-10,15).
Lop: What must I do next?  > Lop moved back by 5 steps.
 > Lop now at position (-5,15).
Lop: What must I do next?  > Lop turned left.
 > Lop now at position (-5,15).
 > Lop moved forward by 5 steps.
 > Lop now at position (-5,10).
 > Lop replayed 2 commands.
 > Lop now at position (-5,10).
Lop: What must I do next? Lop: Shutting down..\n''')


    @patch('sys.stdin', StringIO("Lop\nForward 10\nright\nback 10\nleft\nforward 5\nleft\nback 5\nreplay 4-2 silent\noff"))
    def test_replay_limit_range_silent(self):
        """test full limit range silent
        """        
        obstacles.random.randint = lambda a, b: 0
        sys.stdout = io.StringIO()
        robot.robot_start()
        self.assertEqual(sys.stdout.getvalue(),'''What do you want to name your robot? Lop: Hello kiddo!
Lop: What must I do next?  > Lop moved forward by 10 steps.
 > Lop now at position (0,10).
Lop: What must I do next?  > Lop turned right.
 > Lop now at position (0,10).
Lop: What must I do next?  > Lop moved back by 10 steps.
 > Lop now at position (-10,10).
Lop: What must I do next?  > Lop turned left.
 > Lop now at position (-10,10).
Lop: What must I do next?  > Lop moved forward by 5 steps.
 > Lop now at position (-10,15).
Lop: What must I do next?  > Lop turned left.
 > Lop now at position (-10,15).
Lop: What must I do next?  > Lop moved back by 5 steps.
 > Lop now at position (-5,15).
Lop: What must I do next?  > Lop replayed 2 commands silently.
 > Lop now at position (-5,10).
Lop: What must I do next? Lop: Shutting down..\n''')


    @patch('sys.stdin', StringIO("Bobbo\nForward 1\nforward 2\nforward 3\nforward 4\nforward 5\nforward 6\nforward 7\nreplay 4-2 reversed\noff"))
    def test_replay_limit_range_reversed(self):
        """Test full limit range reversed
        """        
        obstacles.random.randint = lambda a, b: 0
        sys.stdout = io.StringIO()
        robot.robot_start()
        self.assertEqual(sys.stdout.getvalue(),'''What do you want to name your robot? Bobbo: Hello kiddo!
Bobbo: What must I do next?  > Bobbo moved forward by 1 steps.
 > Bobbo now at position (0,1).
Bobbo: What must I do next?  > Bobbo moved forward by 2 steps.
 > Bobbo now at position (0,3).
Bobbo: What must I do next?  > Bobbo moved forward by 3 steps.
 > Bobbo now at position (0,6).
Bobbo: What must I do next?  > Bobbo moved forward by 4 steps.
 > Bobbo now at position (0,10).
Bobbo: What must I do next?  > Bobbo moved forward by 5 steps.
 > Bobbo now at position (0,15).
Bobbo: What must I do next?  > Bobbo moved forward by 6 steps.
 > Bobbo now at position (0,21).
Bobbo: What must I do next?  > Bobbo moved forward by 7 steps.
 > Bobbo now at position (0,28).
Bobbo: What must I do next?  > Bobbo moved forward by 4 steps.
 > Bobbo now at position (0,32).
 > Bobbo moved forward by 3 steps.
 > Bobbo now at position (0,35).
 > Bobbo replayed 2 commands in reverse.
 > Bobbo now at position (0,35).
Bobbo: What must I do next? Bobbo: Shutting down..\n''')


    @patch('sys.stdin', StringIO("Bobbo\nForward 10\nright\nback 10\nleft\nforward 5\nleft\nback 5\nreplay 6-2 reversed silent\noff"))
    def test_replay_limit_range_reversed_silent(self):
        """Test full limit range reversed silent
        """        
        obstacles.random.randint = lambda a, b: 0
        sys.stdout = io.StringIO()
        robot.robot_start()
        self.assertEqual(sys.stdout.getvalue(),'''What do you want to name your robot? Bobbo: Hello kiddo!
Bobbo: What must I do next?  > Bobbo moved forward by 10 steps.
 > Bobbo now at position (0,10).
Bobbo: What must I do next?  > Bobbo turned right.
 > Bobbo now at position (0,10).
Bobbo: What must I do next?  > Bobbo moved back by 10 steps.
 > Bobbo now at position (-10,10).
Bobbo: What must I do next?  > Bobbo turned left.
 > Bobbo now at position (-10,10).
Bobbo: What must I do next?  > Bobbo moved forward by 5 steps.
 > Bobbo now at position (-10,15).
Bobbo: What must I do next?  > Bobbo turned left.
 > Bobbo now at position (-10,15).
Bobbo: What must I do next?  > Bobbo moved back by 5 steps.
 > Bobbo now at position (-5,15).
Bobbo: What must I do next?  > Bobbo replayed 4 commands in reverse silently.
 > Bobbo now at position (-15,10).
Bobbo: What must I do next? Bobbo: Shutting down..\n''')


    @patch('sys.stdin', StringIO("Bobbo\nForward 10\nright\nback 10\nleft\nforward 5\nleft\nback 5\nreplay 6-2\noff"))
    def test_replay_limit_range_n_bigger_than_m(self):
        """Test full limit range first index bigger that second
        """        
        obstacles.random.randint = lambda a, b: 0
        sys.stdout = io.StringIO()
        robot.robot_start()
        self.assertEqual(sys.stdout.getvalue(),'''What do you want to name your robot? Bobbo: Hello kiddo!
Bobbo: What must I do next?  > Bobbo moved forward by 10 steps.
 > Bobbo now at position (0,10).
Bobbo: What must I do next?  > Bobbo turned right.
 > Bobbo now at position (0,10).
Bobbo: What must I do next?  > Bobbo moved back by 10 steps.
 > Bobbo now at position (-10,10).
Bobbo: What must I do next?  > Bobbo turned left.
 > Bobbo now at position (-10,10).
Bobbo: What must I do next?  > Bobbo moved forward by 5 steps.
 > Bobbo now at position (-10,15).
Bobbo: What must I do next?  > Bobbo turned left.
 > Bobbo now at position (-10,15).
Bobbo: What must I do next?  > Bobbo moved back by 5 steps.
 > Bobbo now at position (-5,15).
Bobbo: What must I do next?  > Bobbo turned right.
 > Bobbo now at position (-5,15).
 > Bobbo moved back by 10 steps.
 > Bobbo now at position (-5,5).
 > Bobbo turned left.
 > Bobbo now at position (-5,5).
 > Bobbo moved forward by 5 steps.
 > Bobbo now at position (-10,5).
 > Bobbo replayed 4 commands.
 > Bobbo now at position (-10,5).
Bobbo: What must I do next? Bobbo: Shutting down..\n''')

        

if __name__ == "__main__":
    unittest.main()