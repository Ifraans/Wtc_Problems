import unittest
import io
import sys
import robot
from io import StringIO
import world.text.world as text_world
import world.turtle.world as turtle_world
import world.obstacles


class TestToyRobot(unittest.TestCase):

    def test_create_obstacles_turtle(self):
        """test create_obstacles function for turtle
        """        
        world.obstacles.random.randint = lambda a, b: 1
        turtle_world.create_obstacles()
        self.assertTrue(len(world.obstacles.my_obstacles) == 1)
        world.obstacles.my_obstacles = []


    def test_is_position_allowed_turtle_true(self):
        """test is_position_allowed function for turtle
        """   
        turtle_world.position_x = 0
        turtle_world.position_y = 0
        world.obstacles.my_obstacles = [(0,51)]
        self.assertEqual(turtle_world.is_position_allowed(0,50),(True,True))
        world.obstacles.my_obstacles = []

    
    def test_is_position_allowed_turtle_false(self):
        """test is_position_allowed function for turtle
        """ 
        turtle_world.position_x = 0
        turtle_world.position_y = 0
        world.obstacles.my_obstacles = [(0,50)]
        self.assertEqual(turtle_world.is_position_allowed(0,50),(True,False))
        world.obstacles.my_obstacles = []


    def test_show_position_turtle(self):
        """test show_position function for turtle
        """ 
        turtle_world.current_direction_index = 1
        turtle_world.position_x = 15
        turtle_world.show_position('Hal')
        self.assertEqual(turtle_world.t.pos(), (15.00, 0.00))
        self.assertEqual(turtle_world.t.heading(),0)
        turtle_world.current_direction_index = 0
        turtle_world.position_x = 0


    def test_create_obstacles_text(self):
        """test create_obstacles function for text
        """  
        world.obstacles.random.randint = lambda a, b: 1
        text_world.create_obstacles()
        self.assertTrue(len(world.obstacles.my_obstacles) == 1)
        world.obstacles.my_obstacles = []


    def test_is_position_allowed_text_true(self):
        """test is_position_allowed function for text
        """ 
        text_world.position_x = 0
        text_world.position_y = 0
        world.obstacles.my_obstacles = [(0,51)]
        self.assertEqual(text_world.is_position_allowed(0,50),(True,True))
        world.obstacles.my_obstacles = []

    
    def test_is_position_allowed_text_false(self):
        """test is_position_allowed function for text
        """ 
        text_world.position_x = 0
        text_world.position_y = 0
        world.obstacles.my_obstacles = [(0,50)]
        self.assertEqual(text_world.is_position_allowed(0,50),(True,False))
        world.obstacles.my_obstacles = []


    def test_show_position_text(self):
        """test show_position function for text
        """ 
        text_world.current_direction_index = 1
        text_world.position_x = 15
        sys.stdout = io.StringIO()
        text_world.show_position('Hal')
        self.assertEqual(sys.stdout.getvalue(),' > Hal now at position (15,0).\n')
        text_world.current_direction_index = 0
        text_world.position_x = 0

    def test_print_obstacles_text(self):
        """test print_obstacles function for text
        """ 
        sys.stdout = io.StringIO()
        world.obstacles.my_obstacles = [(9,20),(-20,-50)]
        text_world.print_obstacles()
        self.assertEqual(sys.stdout.getvalue(),'''There are some obstacles:
- At position 9,20 (to 13,24)
- At position -20,-50 (to -16,-46)\n''')
        world.obstacles.my_obstacles = []


if __name__ == '__main__':
    unittest.main()