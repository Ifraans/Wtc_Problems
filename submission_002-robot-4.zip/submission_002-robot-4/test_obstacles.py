import unittest
import io
import sys
import robot
from io import StringIO

import world.obstacles


class MyTestCase(unittest.TestCase):
    def test_is_position_blocked__is_blocked(self):
        """test is_position_blocked function
        """        
        world.obstacles.my_obstacles = [(0,10)]
        self.assertTrue(world.obstacles.is_position_blocked(1,11))
        world.obstacles.my_obstacles = []


    def test_is_position_blocked__not_blocked(self):
        """test is_position_blocked function
        """
        world.obstacles.my_obstacles = [(0,10)]
        self.assertFalse(world.obstacles.is_position_blocked(0,-11))
        world.obstacles.my_obstacles = []


    def test_is_path_blocked__is_blocked(self):
        """test is_path_blocked function
        """
        world.obstacles.my_obstacles = [(0,10)]
        self.assertTrue(world.obstacles.is_path_blocked(0, 0, 0, 30))
        world.obstacles.my_obstacles = []

    
    def test_is_path_blocked__not_blocked(self):
        """test is_path_blocked function
        """
        world.obstacles.my_obstacles = [(0,10)]
        self.assertFalse(world.obstacles.is_path_blocked(0, 0, 0, -30))
        world.obstacles.my_obstacles = []

    
    def test_get_obstacles(self):
        """test get_obstacles function
        """
        world.obstacles.my_obstacles = [(1,50)]
        self.assertEqual(world.obstacles.get_obstacles(),[(1,50)])
        world.obstacles.my_obstacles = []


    def test_create_obstacles(self):
        """test create_obstacles function
        """
        world.obstacles.random.randint = lambda a, b: 1
        world.obstacles.create_obstacles(-100, 100, -200, 200)
        self.assertEqual(world.obstacles.my_obstacles,[(1,1)])
        world.obstacles.my_obstacles = []


if __name__ == "__main__":
    unittest.main()