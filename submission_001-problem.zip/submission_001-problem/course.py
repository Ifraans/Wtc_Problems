import operator

def create_outline():
    
    #Step 1
    course_topics = set(["Introduction to Python", "Tools of the Trade", "How to make decisions", "How to repeat code", "How to structure data", "Functions", "Modules"])
    course_topics = list(course_topics)
    list.sort(course_topics)
    print("Course Topics:")
    for topic in course_topics:
        print("* " + topic)
    
    #Step 2
    course_map = dict()
    for topic in course_topics:
        course_map.update({topic: ["Problem 1", "Problem 2", "Problem 3"]})
    print("Problems:")
    for topic, problems in course_map.items():
        print("* " + topic + " : ", end='')
        print(*problems, sep=", ")
    
    #Step 3
    student_prog1 = ("Tom", "Tools of the Trade", "Problem 1", " [GRADED]")
    student_prog2 = ("Max", "Introduction to Python", "Problem 3", " [COMPLETED]")
    student_prog3 = ("John", "How to repeat code", "Problem 2", " [STARTED]")
    student_prog4 = ("Liv", "How to make decisions", "Problem 2", " [GRADED]")
    student_prog5 = ("Noah", "Functions", "Problem 1", " [STARTED]")
    student_list = [student_prog1, student_prog2, student_prog3, student_prog4, student_prog5]
    new_list = sorted(student_list, key=operator.itemgetter(3), reverse=True)
    print("Student Progress:")
    i = 1
    for item in new_list:
        print(str(i) + ". ", end='')
        print(*item, sep=" - ")
        i+=1
    pass


if __name__ == "__main__":
    create_outline()
