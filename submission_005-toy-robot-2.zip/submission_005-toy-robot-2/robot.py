def name_the_robot():
    """
    This function requests and saves the name for the robot as well as
    greeting the user - presumably a child
    """

    robot_name = input("What do you want to name your robot? ")
    print(f"{robot_name}: Hello kiddo!")
    return robot_name


def get_user_command(robot_name):
    """
    This function asks for and receives a command from the user
    """
    user_command = input(f"{robot_name}: What must I do next? ")
    return user_command 


def splitting_commands(user_command):
    """
    This function splits the entered command into two using a space as a delimiter
    it is split into the command itself as well as the amount of movement
    """
    
    split_command = user_command.split(" ")
    return split_command


def legal_commands():
    """
    This function contains all commands that can be given
    """

    legal_commands = [
        "off",
        "help",
        "forward",
        "back",
        "right",
        "left",
        "sprint",
        "reset"
    ]
    return legal_commands


def help_command():
    """
    This function prints all legal commands inside of the program
    """

    print("""I can understand these commands:
OFF  - Shut down robot
HELP - provide information about commands
FORWARD - Moves robot forward by x steps
BACK - Moves the robot backwards by x steps
RIGHT - Turns the robot right by 90 degrees
LEFT - Turns the robot right by 90 degrees
SPRINT - Moves the robot forward with a burst of speed that slows as it moves
""")


def is_valid_command(legal_commands, user_command):
    """
    This function strips the entered command of numbers and checks
    it against the list of legal commands in the program to prevent errors
"""

    if user_command.lower() in legal_commands:
        return True
    else:
        return False


def is_legal_movement(user_command, co_ordinates, degrees):
    """This function checks that the movement command entered by the user
    is still within the boundaries of the limited area"""

    movement = user_command[0]
    steps = user_command[1]
    x = co_ordinates[0]
    y = co_ordinates[1]
    legal = True

    if movement == "back":
        steps = int(steps) * -1

    if degrees == 0:
        if ((y + int(steps)) > 200 or (y + int(steps)) < -200):
            return False
    elif degrees == 90:
        if ((x + int(steps)) > 100 or (x + int(steps)) < -100):
            return False
    elif degrees == 180:
        if ((y - int(steps)) > 200 or (y - int(steps)) < -200):
            return False
    elif degrees == 270:
        if ((x - int(steps)) > 100 or (x - int(steps)) < -100):
            return False
    return legal


def movements(robot_name, user_command):
    """
    This function takes the user input and displays how far the robot has moved
    and in what direction
    """

    distance = user_command[0]
    distance = distance.lower()
    steps = user_command[1]

    print(f" > {robot_name} moved {distance} by {steps} steps.")


def turn_direction(robot_name, direction, co_ordinates, user_commands, degrees):
    """
    This keeps track of the degrees the robot has turned and so keeps track of the direction
    it is facing
    """

    direction = "right" if user_commands[0].lower() == "right" else "left"
    
    if direction == "right":
        if (degrees + 90) == 360 or degrees == 360:
            degrees = 0
        else:
            degrees += 90
    elif direction == "left":
        if (degrees - 90) == -360 or degrees == 0:
            degrees = 270
        else:
            degrees -= 90

    print(f" > {robot_name} turned {direction}.")
    print(f" > {robot_name} now at position (%s,%s)." % co_ordinates)
    return degrees
     

def move_cords(user_command, co_ordinates, robot_name, direction, degrees):
    """
    This function takes the current co-ordinates and checks them against
which direction the user is moving the robot, either forwards or backward,
then it will check the direction that the robot is facing and move it accordingly
"""

    distance = user_command[0]
    distance = distance.lower()
    steps = user_command[1]
    x = co_ordinates[0]
    y = co_ordinates[1]

    if distance == "forward" or distance == "sprint":
        if degrees == 0:
            y += int(steps)
        elif degrees == 90:
            x += int(steps)
        elif degrees == 180:
            y -= int(steps)
        elif degrees == 270:
            x -= int(steps)
        print(f" > {robot_name} now at position ({x},{y}).")
        return (x,y)
    if distance == "back":
        if degrees == 0:
            y -= int(steps)
        elif degrees == 90:
            x -= int(steps)
        elif degrees == 180:
            y += int(steps)
        elif degrees == 270:
            x += int(steps)
        print(f" > {robot_name} now at position ({x},{y}).")
        return (x,y)


def sprint_calculation(sprint_distance):
    """
    This function calculates the sprint command and returns 0
    if the distance that was given is 0
    """

    sprint_distance = int(sprint_distance)

    if sprint_distance == 0: return 0
    if sprint_distance > 0:
        sprinted = sprint_distance + sprint_calculation(sprint_distance - 1)
        return sprinted


def sprint_movement(robot_name, sprint_distance):
    """
    This function calculates how far the robot will sprint as well as
    how many steps the robot has moved while sprinting
    """

    sprint_distance = int(sprint_distance)

    if sprint_distance == 0: return 0
    if sprint_distance > 0:
        print(f" > {robot_name} moved forward by {sprint_distance} steps.")
        sprinted = sprint_distance + sprint_movement(robot_name, sprint_distance - 1)
        return sprinted


def proccess_user_command(robot_name, legal_commands):
    """
    This function processes and checks the users inputted commands and continues if they are legal
    but asks for a new command if they are not. It links the user commands to the different functions in the program
    as well as checking that the user has only entered two 'words' at a time - a command and distance -
    to ensure the program can function. This also contains the functionality for the OFF and RESET user commands.
    """

    co_ordinates = (0,0)
    direction = str()
    degrees = 0

    while True:
        user_command = get_user_command(robot_name)
        split_commands = splitting_commands(user_command)
        if is_valid_command(legal_commands, split_commands[0]) == False:
            print(f"{robot_name}: Sorry, I did not understand '{user_command}'.")
        else:
            if user_command.lower() == "reset":
                co_ordinates = (0,0)
                print(f" > {robot_name} now at position (%s,%s)." % co_ordinates)
            if user_command.lower() == "off":
                return print(f"{robot_name}: Shutting down..")
            if user_command.lower() == "help":
                help_command()
            if split_commands[0].lower() == "forward":
                if not len(split_commands) == 2:
                    print("Please make sure to only give a command as well as a distance")
                else:
                    legal_move = is_legal_movement(split_commands, co_ordinates, degrees)
                    if legal_move:
                        movements(robot_name, split_commands)
                        co_ordinates = move_cords(split_commands, co_ordinates, robot_name,direction, degrees)
                    else: 
                        print(f"{robot_name}: Sorry, I cannot go outside my safe zone.")
                        print(f" > {robot_name} now at position (%s,%s)." % co_ordinates)
            if split_commands[0].lower() == "back":
                if not len(split_commands) == 2:
                    print("Please make sure to only give a command as well as a distance")
                else:
                    legal_move = is_legal_movement(split_commands, co_ordinates, degrees)
                    if legal_move:
                        movements(robot_name, split_commands)
                        co_ordinates = move_cords(split_commands, co_ordinates, robot_name, direction, degrees)
                    else:
                        print("Please make sure to only give a command as well as a distance")
                        print(f" > {robot_name} now at position (%s,%s)." % co_ordinates)
            if split_commands[0].lower() == "right":
                degrees = turn_direction(robot_name, direction, co_ordinates,split_commands, degrees)
            if split_commands[0].lower() == "left":
                degrees = turn_direction(robot_name, direction, co_ordinates,split_commands, degrees)
            if split_commands[0].lower() == "sprint":
                if not len(split_commands) == 2:
                    print("Please make sure to only give a command as well as a distance")
                else:
                    sprint_distance = split_commands[1]
                    total_sprint = sprint_calculation(sprint_distance)
                    legal_move = is_legal_movement(["", total_sprint], co_ordinates, degrees)
                    if legal_move:
                        sprinted = sprint_movement(robot_name, sprint_distance)
                        co_ordinates = move_cords([split_commands[0], str(sprinted)], co_ordinates, robot_name, direction, degrees)
                    else: 
                        print("Please make sure to only give a command as well as a distance")
                        print(f" > {robot_name} now at position (%s,%s)." % co_ordinates)


def robot_start():
    """This is the entry function, do not change"""

    robot_name = name_the_robot()
    proccess_user_command(robot_name, legal_commands())


if __name__ == "__main__":
    robot_start()



# def robot_name():
#     name = input("What do you want to name your robot? ")
#     return name


# def robot_greet(name):
#     print(name+ ": Hello kiddo!")


# def help_command(help_list, command_list):
#     """prints help list"""
#     for i in range(6):
#         print(" ", help_list[i], "-", command_list[i])



# def seperate(command):
#     split_up = command.split(" ")
#     return split_up
    

# def track_forward_position(name,steps):
#     global cords
#     cords[1] += steps
#     print(f" > {name} now at position ({cords[0]},{cords[1]})")


# def track_back_position(name, steps):
#     global cords 
#     cords[1] -= steps
#     print(f" > {name} now at position ({cords[0]},{cords[1]})")

# def move_direction(name, cords, degrees, split_up, direction):
#     direction = 'right' if split_up[0].lower() == 'right' else 'left'
#     if direction == 'right':
#         if (degrees + 90) == 360 or degrees == 360:
#             degrees = 0
#         else:
#             degrees += 90
#     elif direction == 'left':
#         if (degrees - 90) == -360 or degrees == 0:
#             degrees = 270
#         else: 
#             degrees -= 90

#     print(f" > {name} has turned {direction} ")
#     print(f" > {name} now at position {%s,%s}. " % cords)
#     return degrees 
    
# def move_cords(command, cords, name, direction, degrees):
    
#     distance = user_command[0]
#     distance = distance.lower()
#     steps = user_command[1]
#     x = co_ordinates[0]
#     y = co_ordinates[1]

#     if distance == "forward" or distance == "sprint":
#         if degrees == 0:
#             y += int(steps)
#         elif degrees == 90:
#             x += int(steps)
#         elif degrees == 180:
#             y -= int(steps)
#         elif degrees == 270:
#             x -= int(steps)
#         print(f" > {robot_name} now at position ({x},{y}).")
#         return (x,y)
#     if distance == "back":
#         if degrees == 0:
#             y -= int(steps)
#         elif degrees == 90:
#             x -= int(steps)
#         elif degrees == 180:
#             y += int(steps)
#         elif degrees == 270:
#             x += int(steps)
#         print(f" > {robot_name} now at position ({x},{y}).")
#         return (x,y)




# def robot_start():
#     # global cords, direction, degrees
#     cords = [0,0]
#     direction = str()
#     degrees = 0

#     help_list = ['OFF', 'HELP', 'FORWARD', 'BACK', 'RIGHT', 'LEFT']
#     command_list = ['Shut down robot',
#     'provide information about commands',
#     'allows the robot to move forward',
#     'allows the robot to move backward',
#     'allows the robot to turned right',
#     'allows the robot to turned left\n']   
    
#     name = robot_name()
#     robot_greet(name)
    
#     while True:
#         command = input(name + ": What must I do next? ")
#         split_up  = seperate(command)
#         while split_up[0].upper() not in help_list:
#             print(name+": Sorry, I did not understand")
#             command = input( name + ": What must I do next? ")
#         if command.lower() == 'off': 
#             print(name+": Shutting down..")
#             break
#         if command.lower() == 'help':
#             help_command(help_list, command_list)
#         if split_up[0].lower() == 'forward':
#             print(" > "+name,"moved "+split_up[0]+" by "+split_up[1]+" steps")
#             track_forward_position(name,int(split_up[1])) 
#         if split_up[0].lower() == 'back':
#             track_back_position(name, int(split_up[1]))
#         if split_up[0].lower() == 'right':
#             degrees = move_direction(name, cords, degrees, split_up, direction)
#         if split_up[0].lower() == 'left':
#             degrees = move_direction(name, cords, degrees, split_up, direction)

# if __name__ == "__main__":
#     robot_start()

